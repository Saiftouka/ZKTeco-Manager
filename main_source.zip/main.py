import json
import tempfile

from collections import Counter
from io import BytesIO
from pathlib import Path

from fastapi import (
    FastAPI,
    File,
    Form,
    Query,
    Request,
    UploadFile,
)

from fastapi.responses import (
    FileResponse,
    HTMLResponse,
    JSONResponse,
    StreamingResponse,
)

from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from app.services.excel_service import (
    lire_fichier_employes_excel,
)

from app.services.import_service import (
    creer_session_import,
    lire_session_import,
    supprimer_session_import,
)

from app.services.pointeuse_service import (
    ajouter_pointeuse,
    get_pointeuse_par_id,
    get_pointeuses,
    modifier_pointeuse,
    tester_connexion_pointeuse,
)

from app.services.zkteco_service import (
    get_user_pointeuse,
    get_users_pointeuse,
    get_pointages_pointeuse,
    importer_employes,
    modifier_employe_pointeuse,
    preparer_import_employes,
    verifier_nouvel_employe,
    get_proprietes_pointeuse,
    synchroniser_heure_pointeuse,
    redemarrer_pointeuse,
    retirer_privileges_admin_pointeuse,
)

from app.services.pointage_cache_service import (
    lire_cache_pointages,
)

from app.services.pointage_service import (
    creer_excel_pointages,
)

from app.services.backup_service import (
    creer_backup_pointeuse,
    lister_backups_pointeuse,
)

from app.services.maintenance_service import (
    supprimer_pointages_terminal,
)

from app.services.restauration_service import (
    verifier_backup_restauration,
    restaurer_backup_sqlite,
)


# ============================================================
# APPLICATION
# ============================================================

app = FastAPI(
    title="ZKTeco Manager",
    description="Application de gestion des pointeuses ZKTeco",
    version="1.0.0",
)

app.mount(
    "/static",
    StaticFiles(
        directory="app/static"
    ),
    name="static",
)

templates = Jinja2Templates(
    directory="app/templates"
)


# ============================================================
# OUTILS
# ============================================================

def est_actif(valeur):

    if valeur is True:
        return True

    if valeur is False or valeur is None:
        return False

    if isinstance(valeur, int):
        return valeur == 1

    if isinstance(valeur, str):
        return valeur.strip().lower() in (
            "true",
            "1",
            "oui",
            "yes",
            "active",
            "actif",
            "on",
        )

    return bool(valeur)


def normaliser_timestamp_comparaison(
    valeur,
):

    if valeur is None:
        return ""

    if hasattr(
        valeur,
        "isoformat",
    ):
        try:
            return valeur.isoformat(
                timespec="seconds"
            )

        except Exception:
            pass

    return str(
        valeur
    ).strip()


def normaliser_entier_comparaison(
    valeur,
):

    if valeur is None:
        return None

    try:
        return int(
            valeur
        )

    except (
        TypeError,
        ValueError,
    ):
        return str(
            valeur
        ).strip()


def cle_pointage_securite(
    pointage,
):

    return (
        str(
            pointage.get(
                "matricule",
                "",
            )
            or ""
        ).strip(),

        normaliser_timestamp_comparaison(
            pointage.get(
                "timestamp"
            )
        ),

        normaliser_entier_comparaison(
            pointage.get(
                "status"
            )
        ),

        normaliser_entier_comparaison(
            pointage.get(
                "punch"
            )
        ),
    )


def lire_pointages_users_dat(
    dossier_backup,
):

    if not dossier_backup:
        return {
            "success": False,
            "pointages": [],
            "nombre": 0,
            "erreur": (
                "Le dossier du backup est introuvable."
            ),
        }

    chemin = (
        Path(
            dossier_backup
        )
        / "Users.dat"
    )

    if (
        not chemin.exists()
        or not chemin.is_file()
    ):
        return {
            "success": False,
            "pointages": [],
            "nombre": 0,
            "erreur": (
                "Users.dat est introuvable "
                "dans le dernier backup."
            ),
        }

    try:

        with chemin.open(
            mode="r",
            encoding="utf-8",
        ) as fichier:

            contenu = json.load(
                fichier
            )

    except Exception as erreur:

        return {
            "success": False,
            "pointages": [],
            "nombre": 0,
            "erreur": (
                "Impossible de lire Users.dat : "
                + str(erreur)
            ),
        }

    if not isinstance(
        contenu,
        dict,
    ):
        return {
            "success": False,
            "pointages": [],
            "nombre": 0,
            "erreur": (
                "Le format de Users.dat est invalide."
            ),
        }

    if (
        contenu.get("type")
        != "pointages_terminal"
    ):
        return {
            "success": False,
            "pointages": [],
            "nombre": 0,
            "erreur": (
                "Users.dat n'est pas un backup "
                "des pointages du terminal."
            ),
        }

    pointages = contenu.get(
        "data"
    )

    if not isinstance(
        pointages,
        list,
    ):
        return {
            "success": False,
            "pointages": [],
            "nombre": 0,
            "erreur": (
                "Les données de Users.dat sont invalides."
            ),
        }

    return {
        "success": True,
        "pointages": pointages,
        "nombre": len(pointages),
        "erreur": None,
    }


# ============================================================
# ACCUEIL
# ============================================================

@app.get(
    "/",
    response_class=HTMLResponse,
    name="accueil",
)
def accueil(
    request: Request,
):

    return templates.TemplateResponse(
        request=request,
        name="accueil.html",
        context={
            "active_page": "accueil",
        },
    )


# ============================================================
# DASHBOARD
# ============================================================

@app.get(
    "/dashboard",
    response_class=HTMLResponse,
    name="dashboard",
)
def dashboard(
    request: Request,
):

    resultat = get_pointeuses()

    liste = resultat.get(
        "pointeuses",
        [],
    )

    if not isinstance(
        liste,
        list,
    ):
        liste = []

    data = []

    for pointeuse in liste:

        data.append(
            {
                "id": pointeuse.get("id"),
                "nom": pointeuse.get("nom"),
                "ip": pointeuse.get("ip"),
                "port": pointeuse.get("port"),

                "active": est_actif(
                    pointeuse.get(
                        "active"
                    )
                ),

                "connectee": None,
                "ping": False,
                "firmware": None,
                "heure": None,
                "erreur": None,
            }
        )

    return templates.TemplateResponse(
        request=request,
        name="dashboard.html",
        context={
            "active_page": "dashboard",
            "pointeuses": data,
        },
    )


# ============================================================
# ETAT D'UNE POINTEUSE
# ============================================================

@app.get(
    "/api/pointeuses/{pointeuse_id}/etat",
    name="api_etat_pointeuse",
)
def api_etat_pointeuse(
    pointeuse_id: int,
):

    resultat = get_pointeuse_par_id(
        pointeuse_id
    )

    if resultat.get("success") is not True:

        return JSONResponse(
            status_code=404,
            content={
                "success": False,
                "pointeuse_id": pointeuse_id,
                "active": False,
                "connectee": False,
                "ping": False,
                "firmware": None,
                "heure": None,
                "erreur": (
                    resultat.get("erreur")
                    or "Pointeuse introuvable."
                ),
            },
        )

    pointeuse = resultat.get(
        "pointeuse"
    )

    if not isinstance(
        pointeuse,
        dict,
    ):

        return JSONResponse(
            status_code=404,
            content={
                "success": False,
                "pointeuse_id": pointeuse_id,
                "active": False,
                "connectee": False,
                "ping": False,
                "firmware": None,
                "heure": None,
                "erreur": "Pointeuse introuvable.",
            },
        )

    if not est_actif(
        pointeuse.get("active")
    ):

        return {
            "success": True,
            "pointeuse_id": pointeuse_id,
            "active": False,
            "connectee": False,
            "ping": False,
            "firmware": None,
            "heure": None,
            "erreur": None,
        }

    try:

        connexion = (
            tester_connexion_pointeuse(
                ip=pointeuse.get("ip"),
                port=pointeuse.get("port"),
            )
        )

        if not isinstance(
            connexion,
            dict,
        ):

            return {
                "success": False,
                "pointeuse_id": pointeuse_id,
                "active": True,
                "connectee": False,
                "ping": False,
                "firmware": None,
                "heure": None,
                "erreur": (
                    "Réponse de connexion invalide."
                ),
            }

        connexion_zkteco = (
            connexion.get("success")
            is True
        )

        ping_ok = (
            connexion.get("ping")
            is True
        )

        heure = connexion.get(
            "heure"
        )

        return {
            "success": True,
            "pointeuse_id": pointeuse_id,
            "active": True,

            "connectee": (
                connexion_zkteco
                or ping_ok
            ),

            "ping": ping_ok,

            "connexion_zkteco": (
                connexion_zkteco
            ),

            "firmware": connexion.get(
                "firmware"
            ),

            "heure": (
                str(heure)
                if heure is not None
                else None
            ),

            "erreur": connexion.get(
                "erreur"
            ),
        }

    except Exception as erreur:

        return {
            "success": False,
            "pointeuse_id": pointeuse_id,
            "active": True,
            "connectee": False,
            "ping": False,
            "connexion_zkteco": False,
            "firmware": None,
            "heure": None,
            "erreur": str(erreur),
        }


# ============================================================
# NOMBRE DE POINTAGES DANS LA POINTEUSE PHYSIQUE
#
# Utilisé par la future flèche ↻ de pointages.html.
#
# Lecture uniquement.
#
# Aucune synchronisation SQLite.
# Aucune suppression.
# Aucune modification de la pointeuse.
# ============================================================

@app.get(
    "/api/pointeuses/{pointeuse_id}/nombre-pointages",
    name="api_nombre_pointages_pointeuse",
)
def api_nombre_pointages_pointeuse(
    pointeuse_id: int,
):

    resultat = get_pointeuse_par_id(
        pointeuse_id
    )

    if resultat.get("success") is not True:

        return JSONResponse(
            status_code=404,
            content={
                "success": False,
                "pointeuse_id": pointeuse_id,
                "nombre": None,
                "source": "terminal",

                "erreur": (
                    resultat.get("erreur")
                    or "Pointeuse introuvable."
                ),
            },
        )

    pointeuse = resultat.get(
        "pointeuse"
    )

    if not isinstance(
        pointeuse,
        dict,
    ):

        return JSONResponse(
            status_code=404,
            content={
                "success": False,
                "pointeuse_id": pointeuse_id,
                "nombre": None,
                "source": "terminal",
                "erreur": "Pointeuse introuvable.",
            },
        )

    if not est_actif(
        pointeuse.get("active")
    ):

        return JSONResponse(
            status_code=400,
            content={
                "success": False,
                "pointeuse_id": pointeuse_id,
                "nombre": None,
                "source": "terminal",
                "erreur": "La pointeuse est inactive.",
            },
        )

    try:

       resultat_pointages = (
    get_pointages_pointeuse(
        ip=pointeuse.get("ip"),
        port=pointeuse.get("port"),
        forcer_actualisation=True,
    )
)

    except Exception as erreur:

        return JSONResponse(
            status_code=500,
            content={
                "success": False,
                "pointeuse_id": pointeuse_id,
                "nombre": None,
                "source": "terminal",

                "erreur": (
                    "Impossible de lire les pointages : "
                    + str(erreur)
                ),
            },
        )

    if not isinstance(
        resultat_pointages,
        dict,
    ):

        return JSONResponse(
            status_code=500,
            content={
                "success": False,
                "pointeuse_id": pointeuse_id,
                "nombre": None,
                "source": "terminal",
                "erreur": (
                    "Réponse invalide pendant "
                    "la lecture des pointages."
                ),
            },
        )

    if (
        resultat_pointages.get("success")
        is not True
    ):

        return JSONResponse(
            status_code=400,
            content={
                "success": False,
                "pointeuse_id": pointeuse_id,
                "nombre": None,
                "source": "terminal",

                "performance": (
                    resultat_pointages.get(
                        "performance"
                    )
                ),

                "erreur": (
                    resultat_pointages.get("erreur")
                    or "Impossible de lire les pointages."
                ),
            },
        )

    pointages = resultat_pointages.get(
        "pointages",
        [],
    )

    if not isinstance(
        pointages,
        list,
    ):
        pointages = []

    return {
        "success": True,

        "pointeuse_id": pointeuse_id,

        "nom": pointeuse.get(
            "nom"
        ),

        "ip": pointeuse.get(
            "ip"
        ),

        "port": pointeuse.get(
            "port"
        ),

        "nombre": len(
            pointages
        ),

        "source": (
            "terminal_get_attendance"
        ),

        "performance": (
            resultat_pointages.get(
                "performance"
            )
        ),

        "erreur": None,
    }


# ============================================================
# POINTAGES
# ============================================================

## ============================================================
# POINTAGES
#
# IMPORTANT :
#
# Le compteur affiché correspond uniquement
# aux données présentes dans la pointeuse physique.
#
# Aucune valeur SQLite n'est utilisée ici.
#
# Le compteur physique est lu uniquement lorsque
# l'utilisateur clique sur ↻.
# ============================================================

@app.get(
    "/pointages",
    response_class=HTMLResponse,
    name="pointages",
)
def pointages(
    request: Request,
):
    resultat_pointeuses = (
        get_pointeuses()
    )

    liste = resultat_pointeuses.get(
        "pointeuses",
        [],
    )

    if not isinstance(
        liste,
        list,
    ):
        liste = []

    sortie = []

    for pointeuse in liste:

        sortie.append(
            {
                "id": pointeuse.get(
                    "id"
                ),

                "nom": pointeuse.get(
                    "nom"
                ),

                "ip": pointeuse.get(
                    "ip"
                ),

                "port": pointeuse.get(
                    "port"
                ),

                "active": est_actif(
                    pointeuse.get(
                        "active"
                    )
                ),

                # --------------------------------------------
                # IMPORTANT
                #
                # Ne jamais remettre ici :
                #
                # lire_cache_pointages(...)
                #
                # Le nombre visible est lu directement
                # depuis la pointeuse avec le bouton ↻.
                # --------------------------------------------

                "nombre_terminal": None,
            }
        )

    return templates.TemplateResponse(
        request=request,
        name="pointages.html",
        context={
            "active_page": "pointages",

            "resultat_pointeuses": (
                resultat_pointeuses
            ),

            "pointeuses": sortie,
        },
    )
# ============================================================
# EXPORT EXCEL DES POINTAGES
# ============================================================

# ============================================================
# TELECHARGER LES POINTAGES EXCEL
#
# IMPORTANT :
#
# Cette route ne vérifie plus SQLite.
#
# creer_excel_pointages() effectue maintenant :
#
# terminal physique
#       ↓
# get_pointages_pointeuse()
#       ↓
# get_attendance()
#       ↓
# filtrage Début / Fin
#       ↓
# Excel
# ============================================================

@app.post(
    "/pointages/telecharger",
    name="telecharger_pointages",
)
def telecharger_pointages(
    pointeuse_id: int = Form(...),
    debut: str = Form(...),
    fin: str = Form(...),
):
    # ========================================================
    # 1. RETROUVER LA POINTEUSE
    # ========================================================

    resultat_pointeuse = (
        get_pointeuse_par_id(
            pointeuse_id
        )
    )

    if (
        resultat_pointeuse.get(
            "success"
        )
        is not True
    ):
        return JSONResponse(
            status_code=404,
            content={
                "success": False,

                "erreur": (
                    resultat_pointeuse.get(
                        "erreur"
                    )
                    or "Pointeuse introuvable."
                ),
            },
        )

    pointeuse = (
        resultat_pointeuse.get(
            "pointeuse"
        )
    )

    if not isinstance(
        pointeuse,
        dict,
    ):
        return JSONResponse(
            status_code=404,
            content={
                "success": False,

                "erreur": (
                    "Pointeuse introuvable."
                ),
            },
        )


    # ========================================================
    # 2. VERIFIER QUE LA POINTEUSE EST ACTIVE
    # ========================================================

    if not est_actif(
        pointeuse.get(
            "active"
        )
    ):
        return JSONResponse(
            status_code=400,
            content={
                "success": False,

                "erreur": (
                    "La pointeuse sélectionnée "
                    "est inactive."
                ),
            },
        )


    # ========================================================
    # 3. VERIFIER LA PERIODE
    # ========================================================

    debut = str(
        debut
        or ""
    ).strip()

    fin = str(
        fin
        or ""
    ).strip()

    if not debut:

        return JSONResponse(
            status_code=400,
            content={
                "success": False,

                "erreur": (
                    "La date et l'heure "
                    "de début sont obligatoires."
                ),
            },
        )

    if not fin:

        return JSONResponse(
            status_code=400,
            content={
                "success": False,

                "erreur": (
                    "La date et l'heure "
                    "de fin sont obligatoires."
                ),
            },
        )


    # ========================================================
    # 4. CREER EXCEL
    #
    # IMPORTANT :
    # cette fonction lit maintenant directement
    # la pointeuse physique.
    # ========================================================

    try:

        resultat_excel = (
            creer_excel_pointages(
                pointeuse_id=pointeuse_id,

                nom_pointeuse=(
                    pointeuse.get(
                        "nom"
                    )
                ),

                ip=pointeuse.get(
                    "ip"
                ),

                port=pointeuse.get(
                    "port"
                ),

                date_heure_debut=debut,

                date_heure_fin=fin,
            )
        )

    except Exception as erreur:

        return JSONResponse(
            status_code=500,
            content={
                "success": False,

                "erreur": (
                    "Erreur pendant "
                    "la génération du fichier Excel : "
                    + str(erreur)
                ),
            },
        )


    # ========================================================
    # 5. VERIFIER LE RESULTAT
    # ========================================================

    if not isinstance(
        resultat_excel,
        dict,
    ):
        return JSONResponse(
            status_code=500,
            content={
                "success": False,

                "erreur": (
                    "Réponse invalide pendant "
                    "la génération du fichier Excel."
                ),
            },
        )


    if (
        resultat_excel.get(
            "success"
        )
        is not True
    ):
        return JSONResponse(
            status_code=400,
            content=resultat_excel,
        )


    # ========================================================
    # 6. CONTENU DU FICHIER
    # ========================================================

    contenu = (
        resultat_excel.get(
            "contenu"
        )
    )

    if contenu is None:
        return JSONResponse(
            status_code=500,
            content={
                "success": False,

                "erreur": (
                    "Le fichier Excel "
                    "n'a pas pu être généré."
                ),
            },
        )


    if not isinstance(
        contenu,
        bytes,
    ):
        return JSONResponse(
            status_code=500,
            content={
                "success": False,

                "erreur": (
                    "Le contenu du fichier Excel "
                    "est invalide."
                ),
            },
        )


    if len(contenu) == 0:
        return JSONResponse(
            status_code=500,
            content={
                "success": False,

                "erreur": (
                    "Le fichier Excel généré "
                    "est vide."
                ),
            },
        )


    # ========================================================
    # 7. NOM DU FICHIER
    # ========================================================

    nom_fichier = (
        resultat_excel.get(
            "nom_fichier"
        )
        or "pointages.xlsx"
    )


    # ========================================================
    # 8. TELECHARGEMENT
    # ========================================================

    return StreamingResponse(
        BytesIO(
            contenu
        ),

        media_type=(
            "application/vnd.openxmlformats-"
            "officedocument.spreadsheetml.sheet"
        ),

        headers={
            "Content-Disposition": (
                'attachment; filename="'
                + str(
                    nom_fichier
                )
                + '"'
            ),

            # Informations utiles pour diagnostic.
            "X-Pointages-Source": (
                "terminal"
            ),

            "X-Pointages-Exportes": str(
                resultat_excel.get(
                    "nombre",
                    0,
                )
            ),

            "X-Pointages-Terminal": str(
                resultat_excel.get(
                    "nombre_terminal",
                    0,
                )
            ),
        },
    )

# ============================================================
# EMPLOYES
# ============================================================

@app.get(
    "/employes",
    response_class=HTMLResponse,
    name="employes",
)
def employes(
    request: Request,

    pointeuse_id: int | None = Query(
        default=None
    ),
):

    resultat_pointeuses = (
        get_pointeuses()
    )

    liste = resultat_pointeuses.get(
        "pointeuses",
        [],
    )

    if not isinstance(
        liste,
        list,
    ):
        liste = []

    selection = None

    if pointeuse_id is not None:

        for pointeuse in liste:

            try:
                identifiant = int(
                    pointeuse.get(
                        "id",
                        0,
                    )
                )

            except (
                TypeError,
                ValueError,
            ):
                continue

            if identifiant == pointeuse_id:

                selection = pointeuse
                break

    if selection is None:

        erreur = (
            "Aucune pointeuse n'a été sélectionnée."
            if pointeuse_id is None
            else (
                "La pointeuse sélectionnée "
                "est introuvable."
            )
        )

        resultat = {
            "success": False,
            "utilisateurs": [],
            "nombre": 0,
            "erreur": erreur,
        }

        return templates.TemplateResponse(
            request=request,
            name="employes.html",
            context={
                "active_page": "pointeuses",
                "resultat": resultat,
                "utilisateurs": [],
                "pointeuse_selectionnee": None,
                "pointeuse_id": pointeuse_id,
            },
        )

    resultat = get_users_pointeuse(
        ip=selection.get("ip"),
        port=selection.get("port"),
    )

    return templates.TemplateResponse(
        request=request,
        name="employes.html",
        context={
            "active_page": "pointeuses",

            "resultat": resultat,

            "utilisateurs": resultat.get(
                "utilisateurs",
                [],
            ),

            "pointeuse_selectionnee": (
                selection
            ),

            "pointeuse_id": pointeuse_id,
        },
    )


# ============================================================
# MODIFIER EMPLOYE
# ============================================================

@app.get(
    "/employes/{uid}/modifier",
    response_class=HTMLResponse,
    name="modifier_employe_page",
)
def modifier_employe_page(
    request: Request,
    uid: int,
    pointeuse_id: int = Query(...),
):

    resultat = get_pointeuse_par_id(
        pointeuse_id
    )

    if resultat.get("success") is not True:

        return JSONResponse(
            status_code=404,
            content=resultat,
        )

    pointeuse = resultat.get(
        "pointeuse"
    )

    if not isinstance(
        pointeuse,
        dict,
    ):

        return JSONResponse(
            status_code=404,
            content={
                "success": False,
                "erreur": "Pointeuse introuvable.",
            },
        )

    utilisateur = get_user_pointeuse(
        ip=pointeuse.get("ip"),
        port=pointeuse.get("port"),
        uid=uid,
    )

    if (
        utilisateur.get("success")
        is not True
    ):

        return JSONResponse(
            status_code=404,
            content=utilisateur,
        )

    return templates.TemplateResponse(
        request=request,
        name="modifier_employe.html",

        context={
            "active_page": "pointeuses",
            "pointeuse": pointeuse,

            "utilisateur": utilisateur.get(
                "utilisateur"
            ),
        },
    )


@app.post(
    "/employes/{uid}/modifier",
    name="enregistrer_modification_employe",
)
def enregistrer_modification_employe(
    uid: int,
    pointeuse_id: int = Form(...),
    matricule: str = Form(...),
    nom: str = Form(...),
    badge: str = Form(...),
    role: str = Form(...),
):

    resultat_pointeuse = (
        get_pointeuse_par_id(
            pointeuse_id
        )
    )

    if (
        resultat_pointeuse.get("success")
        is not True
    ):

        return JSONResponse(
            status_code=404,
            content=resultat_pointeuse,
        )

    pointeuse = resultat_pointeuse.get(
        "pointeuse"
    )

    resultat = (
        modifier_employe_pointeuse(
            ip=pointeuse.get("ip"),
            port=pointeuse.get("port"),
            uid=uid,
            matricule=matricule,
            nom=nom,
            badge=badge,
            role=role,
        )
    )

    if resultat.get("success") is True:
        return resultat

    return JSONResponse(
        status_code=400,
        content=resultat,
    )


# ============================================================
# AJOUTER EMPLOYE
# ============================================================


@app.get(
    "/employes/ajouter",
    response_class=HTMLResponse,
    name="ajouter_employe",
)
def ajouter_employe(
    request: Request,
    pointeuse_id: int = Query(...),
):
    # ========================================================
    # RETROUVER LA POINTEUSE
    # ========================================================

    resultat_pointeuse = (
        get_pointeuse_par_id(
            pointeuse_id
        )
    )

    if (
        resultat_pointeuse.get(
            "success"
        )
        is not True
    ):
        return JSONResponse(
            status_code=404,
            content={
                "success": False,
                "erreur": (
                    resultat_pointeuse.get(
                        "erreur"
                    )
                    or "Pointeuse introuvable."
                ),
            },
        )

    pointeuse = (
        resultat_pointeuse.get(
            "pointeuse"
        )
    )

    if not isinstance(
        pointeuse,
        dict,
    ):
        return JSONResponse(
            status_code=404,
            content={
                "success": False,
                "erreur": (
                    "Pointeuse introuvable."
                ),
            },
        )

    # ========================================================
    # PAGE
    # ========================================================

    return templates.TemplateResponse(
        request=request,
        name="ajouter_employe.html",
        context={
            "active_page": "pointeuses",
            "pointeuse": pointeuse,
            "pointeuse_id": pointeuse_id,
            "resultat": None,
            "form_data": {
                "matricule": "",
                "nom": "",
                "badge": "",
                "role": (
                    "Utilisateur normal"
                ),
            },
        },
    )


# ============================================================
# ENREGISTRER NOUVEL EMPLOYE
# ============================================================


@app.post(
    "/employes/ajouter",
    response_class=HTMLResponse,
    name="enregistrer_nouvel_employe",
)
def enregistrer_nouvel_employe(
    request: Request,
    pointeuse_id: int = Form(...),
    matricule: str = Form(...),
    nom: str = Form(...),
    badge: str = Form(...),
    role: str = Form(
        "Utilisateur normal"
    ),
):
    # ========================================================
    # NORMALISATION
    # ========================================================

    matricule = str(
        matricule
        or ""
    ).strip()

    nom = str(
        nom
        or ""
    ).strip()

    badge = str(
        badge
        or ""
    ).strip()

    role = str(
        role
        or "Utilisateur normal"
    ).strip()

    form_data = {
        "matricule": matricule,
        "nom": nom,
        "badge": badge,
        "role": role,
    }

    # ========================================================
    # RETROUVER POINTEUSE
    # ========================================================

    resultat_pointeuse = (
        get_pointeuse_par_id(
            pointeuse_id
        )
    )

    if (
        resultat_pointeuse.get(
            "success"
        )
        is not True
    ):
        return JSONResponse(
            status_code=404,
            content={
                "success": False,
                "erreur": (
                    resultat_pointeuse.get(
                        "erreur"
                    )
                    or "Pointeuse introuvable."
                ),
            },
        )

    pointeuse = (
        resultat_pointeuse.get(
            "pointeuse"
        )
    )

    if not isinstance(
        pointeuse,
        dict,
    ):
        return JSONResponse(
            status_code=404,
            content={
                "success": False,
                "erreur": (
                    "Pointeuse introuvable."
                ),
            },
        )

    # ========================================================
    # VALIDATION GENERALE
    # ========================================================

    erreurs = []

    if not matricule:
        erreurs.append(
            "Le matricule est obligatoire."
        )

    if not nom:
        erreurs.append(
            "Le nom et prénom sont obligatoires."
        )

    if not badge:
        erreurs.append(
            (
                "Le numéro de badge / carte "
                "est obligatoire."
            )
        )

    elif not badge.isdigit():
        erreurs.append(
            (
                "Le numéro de badge / carte "
                "doit contenir uniquement "
                "des chiffres."
            )
        )

    if role not in (
        "Utilisateur normal",
        "Admin",
    ):
        erreurs.append(
            (
                "Le statut utilisateur "
                "est invalide."
            )
        )

    # ========================================================
    # LIRE LES UTILISATEURS ACTUELS
    # ========================================================

    utilisateurs_existants = []

    if not erreurs:

        resultat_users = (
            get_users_pointeuse(
                ip=pointeuse.get(
                    "ip"
                ),
                port=pointeuse.get(
                    "port"
                ),
            )
        )

        if (
            resultat_users.get(
                "success"
            )
            is not True
        ):
            erreurs.append(
                (
                    "Impossible de vérifier "
                    "les employés déjà présents : "
                    + str(
                        resultat_users.get(
                            "erreur"
                        )
                        or ""
                    )
                )
            )

        else:

            utilisateurs_existants = (
                resultat_users.get(
                    "utilisateurs",
                    [],
                )
            )

            if not isinstance(
                utilisateurs_existants,
                list,
            ):
                utilisateurs_existants = []

    # ========================================================
    # CONTROLER LES DOUBLONS
    # ========================================================

    if not erreurs:

        for utilisateur in (
            utilisateurs_existants
        ):

            matricule_existant = str(
                utilisateur.get(
                    "matricule",
                    "",
                )
                or ""
            ).strip()

            badge_existant = str(
                utilisateur.get(
                    "badge",
                    "",
                )
                or ""
            ).strip()

            if (
                matricule_existant.upper()
                == matricule.upper()
            ):
                erreurs.append(
                    (
                        "Ce matricule existe déjà "
                        "dans la pointeuse."
                    )
                )

            if (
                badge_existant
                and badge_existant == badge
            ):
                erreurs.append(
                    (
                        "Ce numéro de badge / carte "
                        "est déjà attribué "
                        "à un employé."
                    )
                )

    # ========================================================
    # ERREURS
    # ========================================================

    if erreurs:

        return templates.TemplateResponse(
            request=request,
            name="ajouter_employe.html",
            context={
                "active_page": "pointeuses",
                "pointeuse": pointeuse,
                "pointeuse_id": pointeuse_id,
                "resultat": {
                    "success": False,
                    "erreurs": erreurs,
                    "erreur": (
                        erreurs[0]
                        if erreurs
                        else None
                    ),
                },
                "form_data": form_data,
            },
        )

    # ========================================================
    # PREPARER EMPLOYE
    #
    # preparer_import_employes() :
    #
    # - vérifie à nouveau les doublons ;
    # - trouve automatiquement un UID libre ;
    # - prépare l'employé au format attendu par ZKTeco.
    # ========================================================

    employe_source = {
        "ligne": 1,
        "matricule": matricule,
        "nom": nom,
        "badge": badge,
    }

    preparation = (
        preparer_import_employes(
            ip=pointeuse.get(
                "ip"
            ),
            port=pointeuse.get(
                "port"
            ),
            employes=[
                employe_source
            ],
        )
    )

    if (
        not isinstance(
            preparation,
            dict,
        )
        or preparation.get(
            "success"
        )
        is not True
    ):

        erreur_preparation = (
            preparation.get(
                "erreur"
            )
            if isinstance(
                preparation,
                dict,
            )
            else (
                "Réponse de préparation "
                "invalide."
            )
        )

        return templates.TemplateResponse(
            request=request,
            name="ajouter_employe.html",
            context={
                "active_page": "pointeuses",
                "pointeuse": pointeuse,
                "pointeuse_id": pointeuse_id,
                "resultat": {
                    "success": False,
                    "erreurs": [
                        erreur_preparation
                    ],
                    "erreur": (
                        erreur_preparation
                    ),
                },
                "form_data": form_data,
            },
        )

    valides = preparation.get(
        "valides",
        [],
    )

    if not isinstance(
        valides,
        list,
    ):
        valides = []

    # ========================================================
    # PREPARATION REFUSEE
    # ========================================================

    if not valides:

        messages = []

        for erreur in preparation.get(
            "erreurs",
            [],
        ):

            if isinstance(
                erreur,
                dict,
            ):

                for message in erreur.get(
                    "erreurs",
                    [],
                ):
                    messages.append(
                        str(message)
                    )

        if not messages:
            messages = [
                (
                    "L'employé ne peut pas "
                    "être ajouté."
                )
            ]

        return templates.TemplateResponse(
            request=request,
            name="ajouter_employe.html",
            context={
                "active_page": "pointeuses",
                "pointeuse": pointeuse,
                "pointeuse_id": pointeuse_id,
                "resultat": {
                    "success": False,
                    "erreurs": messages,
                    "erreur": messages[0],
                },
                "form_data": form_data,
            },
        )

    # ========================================================
    # ROLE
    #
    # preparer_import_employes prépare normalement
    # l'utilisateur comme utilisateur standard.
    #
    # On transmet le rôle demandé pour permettre
    # son application après création.
    # ========================================================

    employe_a_importer = dict(
        valides[0]
    )

    # ========================================================
    # IMPORT PHYSIQUE
    # ========================================================

    resultat_import = (
        importer_employes(
            ip=pointeuse.get(
                "ip"
            ),
            port=pointeuse.get(
                "port"
            ),
            employes=[
                employe_a_importer
            ],
        )
    )

    if (
        not isinstance(
            resultat_import,
            dict,
        )
        or resultat_import.get(
            "success"
        )
        is not True
    ):

        erreur_import = (
            resultat_import.get(
                "erreur"
            )
            if isinstance(
                resultat_import,
                dict,
            )
            else (
                "Réponse d'import invalide."
            )
        )

        return templates.TemplateResponse(
            request=request,
            name="ajouter_employe.html",
            context={
                "active_page": "pointeuses",
                "pointeuse": pointeuse,
                "pointeuse_id": pointeuse_id,
                "resultat": {
                    "success": False,
                    "erreurs": [
                        erreur_import
                    ],
                    "erreur": erreur_import,
                },
                "form_data": form_data,
            },
        )

    # ========================================================
    # APPLIQUER LE ROLE DEMANDE
    #
    # importer_employes crée le compte.
    # modifier_employe_pointeuse permet ensuite
    # d'appliquer USER_DEFAULT ou USER_ADMIN.
    # ========================================================

    uid_nouveau = employe_a_importer.get(
        "uid"
    )

    resultat_role = (
        modifier_employe_pointeuse(
            ip=pointeuse.get(
                "ip"
            ),
            port=pointeuse.get(
                "port"
            ),
            uid=uid_nouveau,
            matricule=matricule,
            nom=nom,
            badge=badge,
            role=role,
        )
    )

    if (
        not isinstance(
            resultat_role,
            dict,
        )
        or resultat_role.get(
            "success"
        )
        is not True
    ):

        return templates.TemplateResponse(
            request=request,
            name="ajouter_employe.html",
            context={
                "active_page": "pointeuses",
                "pointeuse": pointeuse,
                "pointeuse_id": pointeuse_id,
                "resultat": {
                    "success": False,
                    "erreurs": [
                        (
                            "L'employé a été créé, "
                            "mais le statut demandé "
                            "n'a pas pu être appliqué : "
                            + str(
                                resultat_role.get(
                                    "erreur"
                                )
                                if isinstance(
                                    resultat_role,
                                    dict,
                                )
                                else ""
                            )
                        )
                    ],
                    "erreur": (
                        "Employé créé, mais erreur "
                        "pendant l'application du statut."
                    ),
                },
                "form_data": form_data,
            },
        )

    # ========================================================
    # SUCCES
    # ========================================================

    return templates.TemplateResponse(
        request=request,
        name="ajouter_employe.html",
        context={
            "active_page": "pointeuses",
            "pointeuse": pointeuse,
            "pointeuse_id": pointeuse_id,
            "resultat": {
                "success": True,
                "message": (
                    "L'employé a été ajouté "
                    "avec succès dans la pointeuse."
                ),
                "uid": uid_nouveau,
                "matricule": matricule,
                "nom": nom,
                "badge": badge,
                "role": role,
                "erreur": None,
            },
            "form_data": {
                "matricule": "",
                "nom": "",
                "badge": "",
                "role": (
                    "Utilisateur normal"
                ),
            },
        },
    )


# ============================================================
# POINTEUSES
# ============================================================

@app.get(
    "/pointeuses",
    response_class=HTMLResponse,
    name="pointeuses",
)
def pointeuses(
    request: Request,
):

    resultat = get_pointeuses()

    return templates.TemplateResponse(
        request=request,
        name="pointeuses.html",

        context={
            "active_page": "pointeuses",
            "resultat": resultat,

            "pointeuses": resultat.get(
                "pointeuses",
                [],
            ),
        },
    )


# ============================================================
# AJOUTER POINTEUSE
# ============================================================

@app.get(
    "/pointeuses/ajouter",
    response_class=HTMLResponse,
    name="ajouter_pointeuse",
)
def page_ajouter_pointeuse(
    request: Request,
):

    return templates.TemplateResponse(
        request=request,
        name="ajouter_pointeuse.html",

        context={
            "active_page": "pointeuses",
            "resultat_test": None,

            "form_data": {
                "nom": "",
                "ip": "",
                "port": "4370",
            },
        },
    )


@app.post(
    "/pointeuses/tester",
    response_class=HTMLResponse,
    name="tester_pointeuse",
)
def tester_pointeuse(
    request: Request,
    nom: str = Form(...),
    ip: str = Form(...),
    port: str = Form(...),
):

    nom = nom.strip()
    ip = ip.strip()
    port = port.strip()

    resultat_test = (
        tester_connexion_pointeuse(
            ip=ip,
            port=port,
        )
    )

    return templates.TemplateResponse(
        request=request,
        name="ajouter_pointeuse.html",

        context={
            "active_page": "pointeuses",
            "resultat_test": resultat_test,

            "form_data": {
                "nom": nom,
                "ip": ip,
                "port": port,
            },
        },
    )


@app.post(
    "/pointeuses/enregistrer",
    name="enregistrer_pointeuse",
)
def enregistrer_pointeuse(
    nom: str = Form(...),
    ip: str = Form(...),
    port: str = Form(...),
):

    return ajouter_pointeuse(
        nom=nom.strip(),
        ip=ip.strip(),
        port=port.strip(),
        active=True,
    )


# ============================================================
# MODIFIER POINTEUSE
# ============================================================

@app.get(
    "/pointeuses/{pointeuse_id}/modifier",
    response_class=HTMLResponse,
    name="modifier_pointeuse_page",
)
def modifier_pointeuse_page(
    request: Request,
    pointeuse_id: int,
):

    resultat = get_pointeuse_par_id(
        pointeuse_id
    )

    if resultat.get("success") is not True:

        return templates.TemplateResponse(
            request=request,
            name="modifier_pointeuse.html",

            context={
                "active_page": "pointeuses",
                "pointeuse": None,

                "erreur": resultat.get(
                    "erreur"
                ),
            },

            status_code=404,
        )

    return templates.TemplateResponse(
        request=request,
        name="modifier_pointeuse.html",

        context={
            "active_page": "pointeuses",

            "pointeuse": resultat.get(
                "pointeuse"
            ),

            "erreur": None,
        },
    )


@app.post(
    "/pointeuses/{pointeuse_id}/tester-modification",
    name="tester_modification_pointeuse",
)
def tester_modification_pointeuse(
    pointeuse_id: int,
    nom: str = Form(...),
    ip: str = Form(...),
    port: str = Form(...),
    active: str = Form("false"),
):

    resultat = tester_connexion_pointeuse(
        ip=ip.strip(),
        port=port.strip(),
    )

    heure = resultat.get(
        "heure"
    )

    return {
        "success": resultat.get(
            "success",
            False,
        ),

        "ip": resultat.get("ip"),
        "port": resultat.get("port"),

        "ping": resultat.get(
            "ping",
            False,
        ),

        "firmware": resultat.get(
            "firmware"
        ),

        "heure": (
            str(heure)
            if heure is not None
            else None
        ),

        "erreur": resultat.get(
            "erreur"
        ),
    }


@app.post(
    "/pointeuses/{pointeuse_id}/enregistrer-modification",
    name="enregistrer_modification_pointeuse",
)
def enregistrer_modification_pointeuse(
    pointeuse_id: int,
    nom: str = Form(...),
    ip: str = Form(...),
    port: str = Form(...),
    active: str = Form("false"),
):

    resultat = modifier_pointeuse(
        pointeuse_id=pointeuse_id,
        nom=nom.strip(),
        ip=ip.strip(),
        port=port.strip(),
        active=est_actif(active),
    )

    if resultat.get("success") is not True:

        return JSONResponse(
            status_code=400,
            content=resultat,
        )

    return {
        "success": True,

        "message": (
            "Les modifications ont été "
            "enregistrées avec succès."
        ),

        "pointeuse": resultat.get(
            "pointeuse"
        ),

        "erreur": None,
    }


# ============================================================
# IMPORT EXCEL
# ============================================================


@app.get(
    "/import-excel",
    response_class=HTMLResponse,
    name="import_excel",
)
def import_excel(
    request: Request,
):
    resultat_pointeuses = get_pointeuses()

    pointeuses = resultat_pointeuses.get(
        "pointeuses",
        [],
    )

    if not isinstance(
        pointeuses,
        list,
    ):
        pointeuses = []

    return templates.TemplateResponse(
        request=request,
        name="import_excel.html",
        context={
            "active_page": "pointeuses",
            "pointeuses": pointeuses,
            "pointeuse_id": None,
            "analyse_excel": None,
            "preparation_import": None,
            "import_id": None,
            "resultat_import": None,
        },
    )


# ============================================================
# ANALYSER FICHIER EXCEL
# ============================================================


@app.post(
    "/import-excel/analyser",
    response_class=HTMLResponse,
    name="analyser_import_excel",
)
async def analyser_import_excel(
    request: Request,
    pointeuse_id: int = Form(...),
    fichier: UploadFile = File(...),
):
    resultat_pointeuses = get_pointeuses()

    pointeuses = resultat_pointeuses.get(
        "pointeuses",
        [],
    )

    if not isinstance(
        pointeuses,
        list,
    ):
        pointeuses = []

    selection = None

    for pointeuse in pointeuses:

        try:
            identifiant = int(
                pointeuse.get(
                    "id",
                    0,
                )
            )

        except (
            TypeError,
            ValueError,
        ):
            continue

        if identifiant == pointeuse_id:
            selection = pointeuse
            break

    analyse = None
    preparation = None
    import_id = None
    chemin = None

    try:

        # ====================================================
        # POINTEUSE
        # ====================================================

        if selection is None:

            analyse = {
                "success": False,
                "employes": [],
                "nombre": 0,
                "erreurs": [
                    "Pointeuse introuvable."
                ],
                "nombre_erreurs": 1,
            }

        elif not est_actif(
            selection.get(
                "active"
            )
        ):

            analyse = {
                "success": False,
                "employes": [],
                "nombre": 0,
                "erreurs": [
                    (
                        "La pointeuse sélectionnée "
                        "est inactive."
                    )
                ],
                "nombre_erreurs": 1,
            }

        # ====================================================
        # FICHIER
        # ====================================================

        elif not fichier.filename:

            analyse = {
                "success": False,
                "employes": [],
                "nombre": 0,
                "erreurs": [
                    (
                        "Aucun fichier Excel "
                        "n'a été sélectionné."
                    )
                ],
                "nombre_erreurs": 1,
            }

        elif not fichier.filename.lower().endswith(
            ".xlsx"
        ):

            analyse = {
                "success": False,
                "employes": [],
                "nombre": 0,
                "erreurs": [
                    (
                        "Le fichier doit être "
                        "au format .xlsx."
                    )
                ],
                "nombre_erreurs": 1,
            }

        else:

            contenu = await fichier.read()

            if not contenu:

                analyse = {
                    "success": False,
                    "employes": [],
                    "nombre": 0,
                    "erreurs": [
                        "Le fichier Excel est vide."
                    ],
                    "nombre_erreurs": 1,
                }

            else:

                # ============================================
                # FICHIER TEMPORAIRE
                # ============================================

                with tempfile.NamedTemporaryFile(
                    delete=False,
                    suffix=".xlsx",
                ) as fichier_temporaire:

                    fichier_temporaire.write(
                        contenu
                    )

                    chemin = Path(
                        fichier_temporaire.name
                    )

                # ============================================
                # ANALYSE AUTOMATIQUE EXCEL
                # ============================================

                analyse = (
                    lire_fichier_employes_excel(
                        chemin
                    )
                )

                if not isinstance(
                    analyse,
                    dict,
                ):

                    raise RuntimeError(
                        (
                            "Réponse invalide du "
                            "service Excel."
                        )
                    )

                employes_excel = analyse.get(
                    "employes",
                    [],
                )

                if not isinstance(
                    employes_excel,
                    list,
                ):
                    employes_excel = []

                # ============================================
                # VERIFIER LES EMPLOYES DANS LA POINTEUSE
                # ============================================

                if employes_excel:

                    preparation = (
                        preparer_import_employes(
                            ip=selection.get(
                                "ip"
                            ),
                            port=selection.get(
                                "port"
                            ),
                            employes=employes_excel,
                        )
                    )

                # ============================================
                # CREER SESSION UNIQUEMENT
                # POUR LES EMPLOYES VALIDES
                # ============================================

                if (
                    isinstance(
                        preparation,
                        dict,
                    )
                    and preparation.get(
                        "success"
                    )
                    is True
                ):

                    employes_valides = (
                        preparation.get(
                            "valides",
                            [],
                        )
                    )

                    if not isinstance(
                        employes_valides,
                        list,
                    ):
                        employes_valides = []

                    if employes_valides:

                        resultat_session = (
                            creer_session_import(
                                pointeuse_id=pointeuse_id,
                                employes=employes_valides,
                            )
                        )

                        if (
                            isinstance(
                                resultat_session,
                                dict,
                            )
                            and resultat_session.get(
                                "success"
                            )
                            is True
                        ):

                            import_id = (
                                resultat_session.get(
                                    "import_id"
                                )
                            )

    except Exception as erreur:

        analyse = {
            "success": False,
            "employes": [],
            "nombre": 0,
            "erreurs": [
                (
                    "Impossible d'analyser "
                    "le fichier Excel : "
                    + str(erreur)
                )
            ],
            "nombre_erreurs": 1,
        }

        preparation = None
        import_id = None

    finally:

        if chemin is not None:

            try:

                if chemin.exists():
                    chemin.unlink()

            except Exception:
                pass

        try:
            await fichier.close()

        except Exception:
            pass

    return templates.TemplateResponse(
        request=request,
        name="import_excel.html",
        context={
            "active_page": "pointeuses",
            "pointeuses": pointeuses,
            "pointeuse_id": pointeuse_id,
            "analyse_excel": analyse,
            "preparation_import": preparation,
            "import_id": import_id,
            "resultat_import": None,
        },
    )


# ============================================================
# IMPORT REEL
# ============================================================


@app.post(
    "/import-excel/importer",
    response_class=HTMLResponse,
    name="importer_excel",
)
def importer_excel(
    request: Request,
    import_id: str = Form(...),
):
    resultat_pointeuses = get_pointeuses()

    pointeuses = resultat_pointeuses.get(
        "pointeuses",
        [],
    )

    if not isinstance(
        pointeuses,
        list,
    ):
        pointeuses = []

    session = lire_session_import(
        import_id
    )

    pointeuse_id = None
    selection = None
    preparation = None

    if (
        not isinstance(
            session,
            dict,
        )
        or session.get(
            "success"
        )
        is not True
    ):

        resultat_import = {
            "success": False,
            "nombre_importes": 0,
            "erreurs": [],
            "erreur": (
                "La session d'import "
                "est invalide ou expirée."
            ),
        }

    else:

        donnees = session.get(
            "donnees",
            {},
        )

        if not isinstance(
            donnees,
            dict,
        ):
            donnees = {}

        pointeuse_id = donnees.get(
            "pointeuse_id"
        )

        employes = donnees.get(
            "employes",
            [],
        )

        if not isinstance(
            employes,
            list,
        ):
            employes = []

        try:
            pointeuse_id_int = int(
                pointeuse_id
            )

        except (
            TypeError,
            ValueError,
        ):
            pointeuse_id_int = -1

        for pointeuse in pointeuses:

            try:
                identifiant = int(
                    pointeuse.get(
                        "id",
                        0,
                    )
                )

            except (
                TypeError,
                ValueError,
            ):
                continue

            if (
                identifiant
                == pointeuse_id_int
            ):
                selection = pointeuse
                break

        if selection is None:

            resultat_import = {
                "success": False,
                "nombre_importes": 0,
                "erreurs": [],
                "erreur": (
                    "La pointeuse cible "
                    "est introuvable."
                ),
            }

        elif not employes:

            resultat_import = {
                "success": False,
                "nombre_importes": 0,
                "erreurs": [],
                "erreur": (
                    "Aucun employé "
                    "à importer."
                ),
            }

        else:

            # ================================================
            # REVERIFIER AVANT IMPORT
            #
            # Si un employé a été ajouté entre-temps,
            # le doublon est détecté ici.
            # ================================================

            preparation = (
                preparer_import_employes(
                    ip=selection.get(
                        "ip"
                    ),
                    port=selection.get(
                        "port"
                    ),
                    employes=employes,
                )
            )

            if (
                not isinstance(
                    preparation,
                    dict,
                )
                or preparation.get(
                    "success"
                )
                is not True
            ):

                resultat_import = {
                    "success": False,
                    "nombre_importes": 0,
                    "erreurs": (
                        preparation.get(
                            "erreurs",
                            [],
                        )
                        if isinstance(
                            preparation,
                            dict,
                        )
                        else []
                    ),
                    "erreur": (
                        "Impossible de vérifier "
                        "les employés avant import."
                    ),
                }

            else:

                valides = preparation.get(
                    "valides",
                    [],
                )

                if not isinstance(
                    valides,
                    list,
                ):
                    valides = []

                if not valides:

                    resultat_import = {
                        "success": False,
                        "nombre_importes": 0,
                        "erreurs": preparation.get(
                            "erreurs",
                            [],
                        ),
                        "erreur": (
                            "Tous les employés existent "
                            "déjà ou présentent un conflit."
                        ),
                    }

                else:

                    resultat_import = (
                        importer_employes(
                            ip=selection.get(
                                "ip"
                            ),
                            port=selection.get(
                                "port"
                            ),
                            employes=valides,
                        )
                    )

    supprimer_session_import(
        import_id
    )

    return templates.TemplateResponse(
        request=request,
        name="import_excel.html",
        context={
            "active_page": "pointeuses",
            "pointeuses": pointeuses,
            "pointeuse_id": pointeuse_id,
            "analyse_excel": None,
            "preparation_import": preparation,
            "import_id": None,
            "resultat_import": resultat_import,
        },
    )
# ============================================================
# BACKUP
# ============================================================

BACKUP_FILES = {
    "users": "Users.dat",
    "system": "System.dat",
}


def get_dernier_backup(
    pointeuse_id,
):

    resultat = (
        lister_backups_pointeuse(
            pointeuse_id
        )
    )

    if (
        resultat.get("success")
        is not True
    ):
        return None

    backups = resultat.get(
        "backups",
        [],
    )

    return (
        backups[0]
        if backups
        else None
    )


def retrouver_archive_backup(
    dossier_backup,
):

    if not dossier_backup:
        return None

    dossier = Path(
        dossier_backup
    )

    if not dossier.exists():
        return None

    archives = sorted(
        dossier.parent.glob(
            "*.zip"
        ),
        reverse=True,
    )

    for archive in archives:

        if dossier.name in archive.name:
            return archive

    return (
        archives[0]
        if archives
        else None
    )


# ============================================================
# PARAMETRES
# ============================================================

@app.get(
    "/parametres",
    response_class=HTMLResponse,
    name="parametres",
)
def parametres(
    request: Request,

    pointeuse_id: int | None = Query(
        default=None
    ),
):

    resultat_pointeuses = (
        get_pointeuses()
    )

    liste = resultat_pointeuses.get(
        "pointeuses",
        [],
    )

    if not isinstance(
        liste,
        list,
    ):
        liste = []

    if (
        pointeuse_id is None
        and liste
    ):

        try:

            pointeuse_id = int(
                liste[0].get(
                    "id"
                )
            )

        except (
            TypeError,
            ValueError,
        ):

            pointeuse_id = None

    selection = None

    if pointeuse_id is not None:

        for pointeuse in liste:

            try:

                identifiant = int(
                    pointeuse.get(
                        "id"
                    )
                )

            except (
                TypeError,
                ValueError,
            ):
                continue

            if identifiant == pointeuse_id:

                selection = pointeuse
                break

    dernier_backup = (
        get_dernier_backup(
            pointeuse_id
        )
        if selection is not None
        else None
    )

    return templates.TemplateResponse(
        request=request,
        name="parametres.html",

        context={
            "active_page": "parametres",

            "resultat_pointeuses": (
                resultat_pointeuses
            ),

            "pointeuses": liste,

            "nombre_pointeuses": len(
                liste
            ),

            "nombre_actives": sum(
                1
                for pointeuse in liste
                if est_actif(
                    pointeuse.get(
                        "active"
                    )
                )
            ),

            "pointeuse_id": (
                pointeuse_id
            ),

            "pointeuse_selectionnee": (
                selection
            ),

            "dernier_backup": (
                dernier_backup
            ),
        },
    )


# ============================================================
# CREER BACKUP
# ============================================================

@app.post(
    "/parametres/backup/creer",
    name="creer_backup_route",
)
def creer_backup_route(
    pointeuse_id: int = Form(...),
):

    resultat_pointeuse = (
        get_pointeuse_par_id(
            pointeuse_id
        )
    )

    if (
        resultat_pointeuse.get("success")
        is not True
    ):

        return JSONResponse(
            status_code=404,
            content=resultat_pointeuse,
        )

    pointeuse = resultat_pointeuse.get(
        "pointeuse"
    )

    if not isinstance(
        pointeuse,
        dict,
    ):

        return JSONResponse(
            status_code=404,
            content={
                "success": False,
                "erreur": "Pointeuse introuvable.",
            },
        )

    if not est_actif(
        pointeuse.get("active")
    ):

        return JSONResponse(
            status_code=400,
            content={
                "success": False,
                "erreur": (
                    "La pointeuse sélectionnée "
                    "est inactive."
                ),
            },
        )

    resultat = creer_backup_pointeuse(
        pointeuse_id=pointeuse_id,

        nom_pointeuse=(
            pointeuse.get("nom")
        ),

        ip=pointeuse.get("ip"),

        port=pointeuse.get(
            "port"
        ),
    )

    if resultat.get("success") is not True:

        return JSONResponse(
            status_code=400,
            content=resultat,
        )

    return {
        "success": True,

        "backup_valid": resultat.get(
            "backup_valid",
            False,
        ),

        "nombre_pointages": resultat.get(
            "nombre_pointages",
            0,
        ),

        "nombre_pointages_users_dat": (
            resultat.get(
                "nombre_pointages_users_dat",
                0,
            )
        ),

        "source_pointages": resultat.get(
            "source_pointages"
        ),

        "message": (
            "Le backup a été créé "
            "et vérifié avec succès."
        ),

        "erreur": None,
    }


# ============================================================
# TELECHARGER DAT
# ============================================================

@app.get(
    "/parametres/backup/{pointeuse_id}/{type_fichier}",
    name="telecharger_backup_dat",
)
def telecharger_backup_dat(
    pointeuse_id: int,
    type_fichier: str,
):

    nom_fichier = BACKUP_FILES.get(
        type_fichier
    )

    if nom_fichier is None:

        return JSONResponse(
            status_code=404,
            content={
                "success": False,
                "erreur": (
                    "Type de fichier backup invalide."
                ),
            },
        )

    dernier_backup = get_dernier_backup(
        pointeuse_id
    )

    if dernier_backup is None:

        return JSONResponse(
            status_code=404,
            content={
                "success": False,
                "erreur": (
                    "Aucun backup trouvé "
                    "pour cette pointeuse."
                ),
            },
        )

    dossier = dernier_backup.get(
        "dossier"
    )

    if not dossier:

        return JSONResponse(
            status_code=404,
            content={
                "success": False,
                "erreur": (
                    "Le dossier du backup "
                    "est introuvable."
                ),
            },
        )

    chemin = (
        Path(dossier)
        / nom_fichier
    )

    if (
        not chemin.exists()
        or not chemin.is_file()
    ):

        return JSONResponse(
            status_code=404,
            content={
                "success": False,

                "erreur": (
                    nom_fichier
                    + " est introuvable."
                ),
            },
        )

    return FileResponse(
        path=str(chemin),
        media_type="application/octet-stream",
        filename=nom_fichier,
    )


# ============================================================
# TELECHARGER ZIP
# ============================================================

@app.get(
    "/parametres/backup/{pointeuse_id}/zip/complet",
    name="telecharger_backup_zip",
)
def telecharger_backup_zip(
    pointeuse_id: int,
):

    resultat_pointeuse = (
        get_pointeuse_par_id(
            pointeuse_id
        )
    )

    if (
        resultat_pointeuse.get("success")
        is not True
    ):

        return JSONResponse(
            status_code=404,
            content=resultat_pointeuse,
        )

    pointeuse = resultat_pointeuse.get(
        "pointeuse"
    )

    dernier_backup = get_dernier_backup(
        pointeuse_id
    )

    if dernier_backup is None:

        return JSONResponse(
            status_code=404,
            content={
                "success": False,
                "erreur": "Aucun backup trouvé.",
            },
        )

    archive = retrouver_archive_backup(
        dernier_backup.get(
            "dossier"
        )
    )

    if (
        archive is None
        or not archive.exists()
        or not archive.is_file()
    ):

        return JSONResponse(
            status_code=404,
            content={
                "success": False,
                "erreur": (
                    "L'archive ZIP est introuvable."
                ),
            },
        )

    nom = str(
        pointeuse.get(
            "nom",
            "pointeuse",
        )
    )

    for caractere in '\\/:*?"<>|':

        nom = nom.replace(
            caractere,
            "_",
        )

    nom = nom.replace(
        " ",
        "_",
    )

    return FileResponse(
        path=str(
            archive
        ),

        media_type="application/zip",

        filename=(
            "Backup_"
            + nom
            + ".zip"
        ),
    )


# ============================================================
# VERIFIER BACKUP DE RESTAURATION
# ============================================================

@app.post(
    "/parametres/restauration/verifier",
    name="verifier_restauration_route",
)
async def verifier_restauration_route(
    pointeuse_id: int = Form(...),
    fichier: UploadFile = File(...),
):

    resultat_pointeuse = (
        get_pointeuse_par_id(
            pointeuse_id
        )
    )

    if (
        resultat_pointeuse.get("success")
        is not True
    ):

        await fichier.close()

        return JSONResponse(
            status_code=404,
            content={
                "success": False,
                "backup_valid": False,

                "erreur": (
                    resultat_pointeuse.get(
                        "erreur"
                    )
                    or "Pointeuse introuvable."
                ),
            },
        )

    pointeuse = resultat_pointeuse.get(
        "pointeuse"
    )

    if not isinstance(
        pointeuse,
        dict,
    ):

        await fichier.close()

        return JSONResponse(
            status_code=404,
            content={
                "success": False,
                "backup_valid": False,
                "erreur": "Pointeuse introuvable.",
            },
        )

    nom_fichier = (
        fichier.filename
        or ""
    )

    if not nom_fichier:

        await fichier.close()

        return JSONResponse(
            status_code=400,
            content={
                "success": False,
                "backup_valid": False,

                "erreur": (
                    "Aucun fichier de backup "
                    "n'a été sélectionné."
                ),
            },
        )

    if not nom_fichier.lower().endswith(
        ".zip"
    ):

        await fichier.close()

        return JSONResponse(
            status_code=400,
            content={
                "success": False,
                "backup_valid": False,

                "erreur": (
                    "Le fichier doit être "
                    "au format ZIP."
                ),
            },
        )

    chemin = None

    try:

        contenu = await fichier.read()

        if not contenu:

            return JSONResponse(
                status_code=400,
                content={
                    "success": False,
                    "backup_valid": False,

                    "erreur": (
                        "Le fichier de backup "
                        "est vide."
                    ),
                },
            )

        with tempfile.NamedTemporaryFile(
            delete=False,
            suffix=".zip",
        ) as fichier_temporaire:

            fichier_temporaire.write(
                contenu
            )

            chemin = Path(
                fichier_temporaire.name
            )

        resultat = (
            verifier_backup_restauration(
                chemin_zip=chemin,
                pointeuse_id=pointeuse_id,
                ip=pointeuse.get("ip"),
                port=pointeuse.get("port"),
            )
        )

        if resultat.get("success") is not True:

            return JSONResponse(
                status_code=400,
                content=resultat,
            )

        return {
            "success": True,
            "backup_valid": True,
            "pointeuse_id": pointeuse_id,

            "pointeuse": pointeuse.get(
                "nom"
            ),

            "nom_fichier": nom_fichier,

            "users_valid": resultat.get(
                "users_valid",
                False,
            ),

            "system_valid": resultat.get(
                "system_valid",
                False,
            ),

            "nombre_pointages": resultat.get(
                "nombre_pointages",
                0,
            ),

            "nombre_pointages_total": (
                resultat.get(
                    "nombre_pointages_total",
                    0,
                )
            ),

            "nombre_pointages_invalides": (
                resultat.get(
                    "nombre_pointages_invalides",
                    0,
                )
            ),

            "nom_pointeuse_backup": (
                resultat.get(
                    "nom_pointeuse_backup"
                )
            ),

            "ip_backup": resultat.get(
                "ip_backup"
            ),

            "source_pointages": resultat.get(
                "source_pointages"
            ),

            "message": resultat.get(
                "message"
            ),

            "erreur": None,
        }

    except Exception as erreur:

        return JSONResponse(
            status_code=500,
            content={
                "success": False,
                "backup_valid": False,

                "erreur": (
                    "Impossible de vérifier "
                    "le backup : "
                    + str(erreur)
                ),
            },
        )

    finally:

        try:
            await fichier.close()

        except Exception:
            pass

        if chemin is not None:

            try:
                if chemin.exists():
                    chemin.unlink()

            except Exception:
                pass


# ============================================================
# RESTAURATION SQLITE
#
# Pas de saisie RESTAURER.
# Aucune suppression.
# ============================================================

@app.post(
    "/parametres/restauration/restaurer",
    name="restaurer_backup_route",
)
async def restaurer_backup_route(
    pointeuse_id: int = Form(...),
    fichier: UploadFile = File(...),
):

    resultat_pointeuse = (
        get_pointeuse_par_id(
            pointeuse_id
        )
    )

    if (
        resultat_pointeuse.get("success")
        is not True
    ):

        await fichier.close()

        return JSONResponse(
            status_code=404,
            content={
                "success": False,
                "historique_conserve": True,
                "terminal_modifie": False,

                "erreur": (
                    resultat_pointeuse.get(
                        "erreur"
                    )
                    or "Pointeuse introuvable."
                ),
            },
        )

    pointeuse = resultat_pointeuse.get(
        "pointeuse"
    )

    if not isinstance(
        pointeuse,
        dict,
    ):

        await fichier.close()

        return JSONResponse(
            status_code=404,
            content={
                "success": False,
                "historique_conserve": True,
                "terminal_modifie": False,
                "erreur": "Pointeuse introuvable.",
            },
        )

    nom_fichier = (
        fichier.filename
        or ""
    )

    if not nom_fichier:

        await fichier.close()

        return JSONResponse(
            status_code=400,
            content={
                "success": False,
                "historique_conserve": True,
                "terminal_modifie": False,

                "erreur": (
                    "Aucun fichier de backup "
                    "n'a été sélectionné."
                ),
            },
        )

    if not nom_fichier.lower().endswith(
        ".zip"
    ):

        await fichier.close()

        return JSONResponse(
            status_code=400,
            content={
                "success": False,
                "historique_conserve": True,
                "terminal_modifie": False,

                "erreur": (
                    "Le fichier doit être "
                    "au format ZIP."
                ),
            },
        )

    chemin = None

    try:

        contenu = await fichier.read()

        if not contenu:

            return JSONResponse(
                status_code=400,
                content={
                    "success": False,
                    "historique_conserve": True,
                    "terminal_modifie": False,

                    "erreur": (
                        "Le fichier de backup "
                        "est vide."
                    ),
                },
            )

        with tempfile.NamedTemporaryFile(
            delete=False,
            suffix=".zip",
        ) as fichier_temporaire:

            fichier_temporaire.write(
                contenu
            )

            chemin = Path(
                fichier_temporaire.name
            )

        resultat = (
            restaurer_backup_sqlite(
                chemin_zip=chemin,
                pointeuse_id=pointeuse_id,
                ip=pointeuse.get("ip"),
                port=pointeuse.get("port"),
            )
        )

        if resultat.get("success") is not True:

            return JSONResponse(
                status_code=400,
                content=resultat,
            )

        return {
            "success": True,
            "pointeuse_id": pointeuse_id,

            "pointeuse": pointeuse.get(
                "nom"
            ),

            "nom_fichier": nom_fichier,
            "backup_valid": True,

            "nombre_backup": resultat.get(
                "nombre_backup",
                0,
            ),

            "nombre_avant": resultat.get(
                "nombre_avant",
                0,
            ),

            "nombre_ajoutes": resultat.get(
                "nombre_ajoutes",
                0,
            ),

            "nombre_ignores": resultat.get(
                "nombre_ignores",
                0,
            ),

            "nombre_apres": resultat.get(
                "nombre_apres",
                0,
            ),

            "historique_conserve": True,
            "terminal_modifie": False,
            "stockage": "sqlite",

            "message": resultat.get(
                "message"
            ),

            "erreur": None,
        }

    except Exception as erreur:

        return JSONResponse(
            status_code=500,
            content={
                "success": False,
                "historique_conserve": True,
                "terminal_modifie": False,

                "erreur": (
                    "Impossible d'effectuer "
                    "la restauration : "
                    + str(erreur)
                ),
            },
        )

    finally:

        try:
            await fichier.close()

        except Exception:
            pass

        if chemin is not None:

            try:
                if chemin.exists():
                    chemin.unlink()

            except Exception:
                pass


# ============================================================
# NETTOYAGE MANUEL SECURISE
#
# Aucune saisie SUPPRIMER.
#
# IMPORTANT :
# aucune suppression automatique.
#
# Cette route n'est exécutée que lorsque l'utilisateur
# clique volontairement sur le bouton Nettoyage.
# ============================================================

@app.post(
    "/parametres/maintenance/nettoyer-pointages",
    name="nettoyer_pointages_route",
)
def nettoyer_pointages_route(
    pointeuse_id: int = Form(...),
):

    resultat_pointeuse = (
        get_pointeuse_par_id(
            pointeuse_id
        )
    )

    if (
        resultat_pointeuse.get("success")
        is not True
    ):

        return JSONResponse(
            status_code=404,
            content={
                "success": False,
                "historique_conserve": True,

                "erreur": (
                    resultat_pointeuse.get(
                        "erreur"
                    )
                    or "Pointeuse introuvable."
                ),
            },
        )

    pointeuse = resultat_pointeuse.get(
        "pointeuse"
    )

    if not isinstance(
        pointeuse,
        dict,
    ):

        return JSONResponse(
            status_code=404,
            content={
                "success": False,
                "historique_conserve": True,
                "erreur": "Pointeuse introuvable.",
            },
        )

    if not est_actif(
        pointeuse.get("active")
    ):

        return JSONResponse(
            status_code=400,
            content={
                "success": False,
                "historique_conserve": True,

                "erreur": (
                    "La pointeuse sélectionnée "
                    "est inactive."
                ),
            },
        )

    # ========================================================
    # BACKUP OBLIGATOIRE
    # ========================================================

    dernier_backup = get_dernier_backup(
        pointeuse_id
    )

    if dernier_backup is None:

        return JSONResponse(
            status_code=400,
            content={
                "success": False,
                "historique_conserve": True,

                "erreur": (
                    "Suppression interdite : "
                    "aucun backup n'est disponible. "
                    "Créez d'abord un backup."
                ),
            },
        )

    if (
        dernier_backup.get(
            "backup_valid"
        )
        is not True
    ):

        return JSONResponse(
            status_code=400,
            content={
                "success": False,
                "historique_conserve": True,

                "erreur": (
                    "Suppression interdite : "
                    "le dernier backup "
                    "n'est pas valide."
                ),
            },
        )

    # ========================================================
    # VERIFIER USERS.DAT
    # ========================================================

    resultat_backup = (
        lire_pointages_users_dat(
            dernier_backup.get(
                "dossier"
            )
        )
    )

    if (
        resultat_backup.get("success")
        is not True
    ):

        return JSONResponse(
            status_code=400,
            content={
                "success": False,
                "historique_conserve": True,

                "erreur": (
                    "Suppression interdite : "
                    + str(
                        resultat_backup.get(
                            "erreur"
                        )
                    )
                ),
            },
        )

    pointages_backup = resultat_backup.get(
        "pointages",
        [],
    )

    nombre_backup = int(
        resultat_backup.get(
            "nombre",
            0,
        )
        or 0
    )

    # ========================================================
    # LECTURE DIRECTE DU TERMINAL
    #
    # Aucune synchronisation.
    # ========================================================

    resultat_terminal = (
        get_pointages_pointeuse(
            ip=pointeuse.get("ip"),
            port=pointeuse.get("port"),
        )
    )

    if (
        resultat_terminal.get("success")
        is not True
    ):

        return JSONResponse(
            status_code=400,
            content={
                "success": False,
                "historique_conserve": True,
                "nombre_backup": nombre_backup,

                "erreur": (
                    "Suppression annulée : "
                    "impossible de relire "
                    "les pointages de la pointeuse. "
                    + str(
                        resultat_terminal.get(
                            "erreur"
                        )
                        or ""
                    )
                ),
            },
        )

    pointages_terminal = (
        resultat_terminal.get(
            "pointages",
            [],
        )
    )

    if not isinstance(
        pointages_terminal,
        list,
    ):

        return JSONResponse(
            status_code=400,
            content={
                "success": False,
                "historique_conserve": True,

                "erreur": (
                    "Suppression annulée : "
                    "lecture terminal invalide."
                ),
            },
        )

    nombre_terminal = len(
        pointages_terminal
    )

    # ========================================================
    # DEJA VIDE
    # ========================================================

    if nombre_terminal == 0:

        return {
            "success": True,
            "pointeuse_id": pointeuse_id,

            "pointeuse": pointeuse.get(
                "nom"
            ),

            "nombre_backup": nombre_backup,
            "nombre_terminal_avant": 0,
            "nombre_supprimes": 0,
            "nombre_restant_terminal": 0,
            "historique_conserve": True,

            "message": (
                "La pointeuse ne contient "
                "déjà aucun pointage."
            ),

            "erreur": None,
        }

    # ========================================================
    # COMPARER LE NOMBRE
    # ========================================================

    if nombre_backup != nombre_terminal:

        return JSONResponse(
            status_code=409,
            content={
                "success": False,
                "historique_conserve": True,
                "backup_valide": True,
                "backup_correspond_terminal": False,
                "nombre_backup": nombre_backup,
                "nombre_terminal": nombre_terminal,

                "erreur": (
                    "Suppression interdite par sécurité : "
                    "le backup contient "
                    + str(nombre_backup)
                    + " pointage(s), alors que "
                    "la pointeuse contient "
                    + str(nombre_terminal)
                    + " pointage(s). "
                    "Créez un nouveau backup."
                ),
            },
        )

    # ========================================================
    # COMPARER LE CONTENU
    # ========================================================

    compteur_backup = Counter(
        cle_pointage_securite(
            pointage
        )
        for pointage
        in pointages_backup
    )

    compteur_terminal = Counter(
        cle_pointage_securite(
            pointage
        )
        for pointage
        in pointages_terminal
    )

    if compteur_backup != compteur_terminal:

        uniquement_backup = (
            compteur_backup
            - compteur_terminal
        )

        uniquement_terminal = (
            compteur_terminal
            - compteur_backup
        )

        return JSONResponse(
            status_code=409,
            content={
                "success": False,
                "historique_conserve": True,
                "backup_valide": True,
                "backup_correspond_terminal": False,
                "nombre_backup": nombre_backup,
                "nombre_terminal": nombre_terminal,

                "nombre_uniquement_backup": sum(
                    uniquement_backup.values()
                ),

                "nombre_uniquement_terminal": sum(
                    uniquement_terminal.values()
                ),

                "erreur": (
                    "Suppression interdite par sécurité : "
                    "Users.dat ne correspond pas "
                    "exactement aux pointages "
                    "de la pointeuse. "
                    "Créez un nouveau backup."
                ),
            },
        )

    # ========================================================
    # VERIFIER SQLITE AVANT
    # ========================================================

    avant = lire_cache_pointages(
        pointeuse_id
    )

    if avant.get("success") is not True:

        return JSONResponse(
            status_code=500,
            content={
                "success": False,
                "historique_conserve": True,
                "backup_correspond_terminal": True,

                "erreur": (
                    "Suppression annulée : "
                    "l'historique SQLite "
                    "n'a pas pu être vérifié."
                ),
            },
        )

    try:

        nombre_sqlite_avant = int(
            avant.get(
                "nombre",
                0,
            )
            or 0
        )

    except (
        TypeError,
        ValueError,
    ):

        return JSONResponse(
            status_code=500,
            content={
                "success": False,
                "historique_conserve": True,

                "erreur": (
                    "Suppression annulée : "
                    "compteur SQLite invalide."
                ),
            },
        )

    # ========================================================
    # SUPPRESSION PHYSIQUE
    #
    # SEULE OPERATION DESTRUCTIVE.
    # ========================================================

    try:

        nettoyage = (
            supprimer_pointages_terminal(
                ip=pointeuse.get("ip"),
                port=pointeuse.get("port"),
            )
        )

    except Exception as erreur:

        return JSONResponse(
            status_code=500,
            content={
                "success": False,

                "historique_local": (
                    nombre_sqlite_avant
                ),

                "historique_conserve": True,
                "backup_correspond_terminal": True,

                "erreur": (
                    "Erreur pendant le nettoyage : "
                    + str(erreur)
                ),
            },
        )

    if not isinstance(
        nettoyage,
        dict,
    ):

        return JSONResponse(
            status_code=500,
            content={
                "success": False,

                "historique_local": (
                    nombre_sqlite_avant
                ),

                "historique_conserve": True,

                "erreur": (
                    "Réponse de maintenance invalide."
                ),
            },
        )

    if nettoyage.get("success") is not True:

        return JSONResponse(
            status_code=400,
            content={
                "success": False,

                "historique_local": (
                    nombre_sqlite_avant
                ),

                "historique_conserve": True,
                "backup_correspond_terminal": True,

                "erreur": (
                    nettoyage.get("erreur")
                    or (
                        "La suppression des pointages "
                        "a échoué."
                    )
                ),
            },
        )

    # ========================================================
    # VERIFIER TERMINAL VIDE
    # ========================================================

    try:

        nombre_restant = int(
            nettoyage.get(
                "nombre_apres",
                0,
            )
            or 0
        )

    except (
        TypeError,
        ValueError,
    ):

        nombre_restant = -1

    if nombre_restant != 0:

        return JSONResponse(
            status_code=400,
            content={
                "success": False,

                "nombre_supprimes": nettoyage.get(
                    "nombre_supprimes",
                    0,
                ),

                "nombre_restant": (
                    nombre_restant
                ),

                "historique_local": (
                    nombre_sqlite_avant
                ),

                "historique_conserve": True,

                "backup_correspond_terminal": True,

                "erreur": (
                    "La suppression n'est pas complète. "
                    + str(nombre_restant)
                    + " pointage(s) sont encore présents."
                ),
            },
        )

    # ========================================================
    # VERIFIER SQLITE APRES
    # ========================================================

    apres = lire_cache_pointages(
        pointeuse_id
    )

    if apres.get("success") is not True:

        return JSONResponse(
            status_code=500,
            content={
                "success": False,
                "nombre_restant_terminal": 0,
                "historique_conserve": True,
                "backup_correspond_terminal": True,

                "erreur": (
                    "La pointeuse est vide, mais "
                    "la vérification finale de SQLite "
                    "a échoué."
                ),
            },
        )

    try:

        nombre_sqlite_apres = int(
            apres.get(
                "nombre",
                0,
            )
            or 0
        )

    except (
        TypeError,
        ValueError,
    ):

        nombre_sqlite_apres = -1

    if (
        nombre_sqlite_apres
        != nombre_sqlite_avant
    ):

        return JSONResponse(
            status_code=500,
            content={
                "success": False,

                "nombre_restant_terminal": 0,

                "historique_local_avant": (
                    nombre_sqlite_avant
                ),

                "historique_local_apres": (
                    nombre_sqlite_apres
                ),

                "historique_conserve": False,

                "backup_correspond_terminal": True,

                "erreur": (
                    "ALERTE : le nombre de "
                    "pointages SQLite a changé "
                    "pendant le nettoyage."
                ),
            },
        )

    # ========================================================
    # SUCCES
    # ========================================================

    return {
        "success": True,

        "pointeuse_id": pointeuse_id,

        "pointeuse": pointeuse.get(
            "nom"
        ),

        "backup_valide": True,
        "backup_correspond_terminal": True,

        "nombre_backup": nombre_backup,

        "nombre_terminal_avant": (
            nombre_terminal
        ),

        "nombre_supprimes": nettoyage.get(
            "nombre_supprimes",
            0,
        ),

        "nombre_restant_terminal": 0,

        "historique_local": (
            nombre_sqlite_apres
        ),

        "historique_conserve": True,

        "message": (
            "Nettoyage terminé avec succès. "
            "Le backup correspondait exactement "
            "aux pointages du terminal. "
            "La pointeuse est maintenant vide "
            "et l'historique SQLite a été conservé."
        ),

        "erreur": None,
    }